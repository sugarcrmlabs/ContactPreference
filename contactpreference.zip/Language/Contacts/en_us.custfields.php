<?php

$mod_strings['LBL_DNC_IMAGE'] = 'Contact Status';
$mod_strings['LBL_PREF'] = 'Contact Preference';