<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/DynamicFields/Ext/Language/en_us.do_not_call_image.php


$mod_strings['LBL_DONOTCALLIMAGEFIELD'] = 'Do Not Call Image';
$mod_strings['LBL_DONOTCALLIMAGEFIELD_FORMAT_HELP'] = '';