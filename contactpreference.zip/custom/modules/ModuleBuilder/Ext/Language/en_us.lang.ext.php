<?php
// WARNING: The contents of this file are auto-generated.

//Merged from custom/Extension/modules/ModuleBuilder/Ext/Language/en_us.do_not_call_image.php


$mod_strings['fieldTypes']['do_not_call_image'] = 'Do Not Call Image';