<?php
 // created: 2016-05-14 17:02:54

$app_list_strings['contact_methods_list']=array (
  'PHONE' => 'Phone',
  'MOBILE' => 'Mobile',
  'EMAIL' => 'Email',
  'OFFICE' => 'Office',
  'FAX' => 'Fax',
  'SMS' => 'SMS',
  'GOOGLE' => 'Google',
  'SKYPE' => 'Skype',
);