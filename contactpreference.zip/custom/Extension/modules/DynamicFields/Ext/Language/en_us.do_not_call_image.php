<?php

$mod_strings['LBL_DONOTCALLIMAGEFIELD'] = 'Do Not Call Image';
$mod_strings['LBL_DONOTCALLIMAGEFIELD_FORMAT_HELP'] = '';