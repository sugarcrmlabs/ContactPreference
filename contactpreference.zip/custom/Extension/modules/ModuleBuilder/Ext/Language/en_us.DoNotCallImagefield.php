<?php

$mod_strings['fieldTypes']['do_not_call_image'] = 'Do Not Call Image';